
# rework-visit

  Rework declaration visitor for plugins (and rework core).

# License

  MIT
