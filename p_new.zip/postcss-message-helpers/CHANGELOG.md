# 2.0.0 - 2014-01-26

- Added: compatibility with postcss v4.x
- Removed: compability with postcss v3.x

# 1.1.1 - 2014-11-24

- Fixed: issue with multilines error message in stack trace
- Added: `originalMessage` property in the exception

# 1.1.0 - 2014-11-24

- Added: `try` now returns the result of the callback

# 1.0.0 - 2014-11-24

✨ First release 
