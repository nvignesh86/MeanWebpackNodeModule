Converts bare objects to DOM objects, compatible with htmlparser2's DOM objects.

This is useful when you want to work with DOM without having to compose/parse html.