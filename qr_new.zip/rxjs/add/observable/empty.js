"use strict";
var Observable_1 = require('../../Observable');
var empty_1 = require('../../observable/empty');
Observable_1.Observable.empty = empty_1.empty;
//# sourceMappingURL=empty.js.map