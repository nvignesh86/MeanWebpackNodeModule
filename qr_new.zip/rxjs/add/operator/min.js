"use strict";
var Observable_1 = require('../../Observable');
var min_1 = require('../../operator/min');
Observable_1.Observable.prototype.min = min_1.min;
//# sourceMappingURL=min.js.map