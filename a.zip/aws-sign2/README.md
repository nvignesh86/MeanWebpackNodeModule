aws-sign
========

AWS signing. Originally pulled from LearnBoost/knox, maintained as vendor in request, now a standalone module.
