"use strict";
var Observable_1 = require('../../Observable');
var using_1 = require('../../observable/using');
Observable_1.Observable.using = using_1.using;
//# sourceMappingURL=using.js.map