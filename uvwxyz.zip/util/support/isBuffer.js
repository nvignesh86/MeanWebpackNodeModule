module.exports = function isBuffer(arg) {
  return arg instanceof Buffer;
}
