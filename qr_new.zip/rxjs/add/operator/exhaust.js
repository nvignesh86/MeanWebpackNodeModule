"use strict";
var Observable_1 = require('../../Observable');
var exhaust_1 = require('../../operator/exhaust');
Observable_1.Observable.prototype.exhaust = exhaust_1.exhaust;
//# sourceMappingURL=exhaust.js.map