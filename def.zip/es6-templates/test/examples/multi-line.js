var s = `a
    b
    c`;
assert.equal(s, 'a\n    b\n    c');
