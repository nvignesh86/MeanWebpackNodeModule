"use strict";
var Observable_1 = require('../../Observable');
var timeInterval_1 = require('../../operator/timeInterval');
Observable_1.Observable.prototype.timeInterval = timeInterval_1.timeInterval;
//# sourceMappingURL=timeInterval.js.map