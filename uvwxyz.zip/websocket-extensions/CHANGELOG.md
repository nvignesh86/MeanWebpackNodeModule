### 0.1.1 / 2015-02-19

* Prevent sessions being closed before they have finished processing messages
* Add a callback to `Extensions.close()` so the caller can tell when it's safe to close the socket

### 0.1.0 / 2014-12-12

* Initial release
