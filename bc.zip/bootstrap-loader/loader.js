// eslint-disable-next-line import/no-webpack-loader-syntax
module.exports = require('./lib/bootstrap.loader!./no-op.js');
